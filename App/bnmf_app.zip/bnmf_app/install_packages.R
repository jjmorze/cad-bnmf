# One-time setup: install the R packages the app needs (CRAN only).
pkgs <- c("shiny", "bslib", "DT", "ggplot2", "inflection", "future", "furrr",
          "parallelly", "openxlsx", "commonmark")
missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) install.packages(missing, repos = "https://cloud.r-project.org")
cat("All packages available:", all(vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)), "\n")
