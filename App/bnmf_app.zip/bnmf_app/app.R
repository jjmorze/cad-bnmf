# =============================================================================
# bNMF Clustering Studio - Shiny GUI for gwas-partitioning/bnmf-clustering
# with Unit Invariant Knee (UIK) cutoffs for cluster allocation of variants.
#
# Run locally:   Rscript -e 'shiny::runApp("path/to/bnmf_app", launch.browser = TRUE)'
# Web:           deploy this folder to Shiny Server / Posit Connect / shinyapps.io,
#                or build the included Dockerfile.
# =============================================================================

suppressPackageStartupMessages({
  library(shiny)
  library(bslib)
  library(DT)
  library(ggplot2)
})

app_dir <- if (exists("app_dir_override")) app_dir_override else getwd()
for (f in list.files(file.path(app_dir, "R"), pattern = "\\.R$", full.names = TRUE)) source(f, local = TRUE)

options(shiny.maxRequestSize = 200 * 1024^2)

theme_app <- theme_minimal(base_size = 13) +
  theme(panel.grid.minor = element_blank(), plot.title = element_text(face = "bold"))

heat_df <- function(mat, row_name, col_name, cluster_rows = TRUE, cluster_cols = TRUE) {
  ro <- if (cluster_rows && nrow(mat) > 2) rownames(mat)[hclust(dist(mat), "ward.D")$order] else rownames(mat)
  co <- if (cluster_cols && ncol(mat) > 2) colnames(mat)[hclust(dist(t(mat)), "ward.D")$order] else colnames(mat)
  df <- data.frame(r = rep(rownames(mat), ncol(mat)), c = rep(colnames(mat), each = nrow(mat)),
                   value = as.numeric(mat), stringsAsFactors = FALSE)
  df$r <- factor(df$r, levels = ro); df$c <- factor(df$c, levels = co)
  names(df)[1:2] <- c(row_name, col_name)
  df
}

# ----------------------------------------------------------------------------- UI
ui <- page_navbar(
  id = "main",
  title = "bNMF Clustering Studio",
  theme = bs_theme(version = 5, bootswatch = "flatly"),
  sidebar = sidebar(
    width = 330,
    accordion(
      open = c("Data", "bNMF"),
      accordion_panel(
        "Data",
        radioButtons("data_src", NULL, c("Mock dataset" = "mock", "Upload my data" = "upload"), inline = TRUE),
        conditionalPanel(
          "input.data_src == 'mock'",
          numericInput("mock_n", "Mock variants", 300, min = 50, max = 3000, step = 50),
          numericInput("mock_seed", "Mock seed", 7, min = 1),
          helpText("5 planted mechanisms across 20 traits; includes a BMI-duplicate (WC) and a null trait to exercise pre-processing.")
        ),
        conditionalPanel(
          "input.data_src == 'upload'",
          fileInput("z_file", "Z-score matrix (CSV/TSV)", accept = c(".csv", ".tsv", ".txt", ".gz")),
          fileInput("n_file", "Sample-size matrix (optional)", accept = c(".csv", ".tsv", ".txt", ".gz")),
          helpText("Wide format: first column = variant ID, one column per trait. Z-scores should already be aligned to the risk allele of the primary trait. Same variant IDs/trait names in the N matrix.")
        )
      ),
      accordion_panel(
        "Pre-processing",
        numericInput("pval_cutoff", "Trait p-value filter (blank = 0.05 / N variants)", NA, min = 0, max = 1),
        sliderInput("corr_cutoff", "Correlation pruning |r| \u2265", 0.5, 1, 0.85, 0.01),
        selectizeInput("rm_traits", "Remove traits", choices = NULL, multiple = TRUE),
        selectizeInput("keep_traits", "Force-keep traits", choices = NULL, multiple = TRUE)
      ),
      accordion_panel(
        "bNMF",
        numericInput("n_reps", "Repetitions", 20, min = 1, max = 1000),
        numericInput("K", "Max clusters K", 20, min = 2, max = 60),
        numericInput("K0", "Prior K0", 10, min = 1, max = 60),
        numericInput("phi", "phi (regularisation)", 1, min = 0.01, step = 0.5),
        selectInput("tol", "Tolerance", c("1e-7" = 1e-7, "1e-6" = 1e-6, "1e-5" = 1e-5), selected = 1e-7),
        numericInput("n_iter", "Max iterations", 10000, min = 200, step = 1000),
        numericInput("seed", "Random seed", 1, min = 1),
        numericInput("workers", "Parallel workers", 1, min = 1, max = max(1, parallel::detectCores() - 1))
      )
    ),
    input_task_button("run", "Run bNMF", icon = icon("play"), class = "btn-primary")
  ),

  nav_panel(
    "1. Data & QC",
    layout_columns(
      col_widths = c(12),
      uiOutput("data_boxes"),
      card(card_header("Trait filtering (prep_z_matrix)"), DTOutput("trait_tbl")),
      card(card_header("Trait\u2013trait correlation of z-scores (after p-value filter)"),
           plotOutput("cor_plot", height = 520))
    )
  ),

  nav_panel(
    "2. bNMF runs",
    layout_columns(
      col_widths = c(5, 7),
      card(card_header("Number of clusters (K) across repetitions"), plotOutput("k_plot", height = 320),
           uiOutput("k_select_ui")),
      card(card_header("Repetitions (sorted by evidence; lower = better)"), DTOutput("run_tbl"))
    )
  ),

  nav_panel(
    "3. Cutoff (UIK)",
    layout_columns(
      col_widths = c(4, 8),
      card(
        card_header("Cluster-allocation cutoff"),
        radioButtons("cut_method", "Method",
                     c("Unit Invariant Knee (UIK)" = "uik",
                       "Elbow: upstream calculate_cutoff()" = "elbow",
                       "Manual" = "manual")),
        conditionalPanel(
          "input.cut_method == 'uik'",
          radioButtons("uik_mode", "UIK mode",
                       c("Global: one cutoff for all clusters" = "global",
                         "Per cluster: UIK on each W column / H row" = "per_cluster")),
          conditionalPanel(
            "input.uik_mode == 'global'",
            radioButtons("uik_scope", "Weight curve",
                         c("Variant weights (W)" = "W", "Pooled W + H (upstream curve)" = "pooled"))
          ),
          checkboxInput("uik_drop_zeros", "Exclude zero weights from the curve", FALSE)
        ),
        conditionalPanel("input.cut_method == 'manual'",
                         numericInput("manual_cut", "Weight cutoff", 0.5, min = 0, step = 0.05)),
        hr(),
        tableOutput("cut_summary"),
        helpText("A variant is allocated to every cluster where its W weight \u2265 that cluster's cutoff (soft clustering). Traits are flagged as cluster-defining where H \u2265 cutoff.")
      ),
      card(card_header("Rank-ordered weight curve"), plotOutput("cut_plot", height = 480))
    )
  ),

  nav_panel(
    "4. Clusters",
    layout_columns(
      col_widths = c(6, 6, 12, 5, 7),
      card(card_header("Variant weights (W)"), plotOutput("w_heat", height = 460)),
      card(card_header("Trait weights (H)"), plotOutput("h_heat", height = 460)),
      card(card_header("Cluster sizes after allocation"), tableOutput("size_tbl")),
      card(card_header("Top traits per cluster"),
           selectInput("clus_sel", "Cluster", choices = NULL), plotOutput("trait_bar", height = 380)),
      card(card_header("Allocated variants"), DTOutput("alloc_tbl"))
    )
  ),

  nav_panel(
    "5. Mock truth",
    uiOutput("truth_ui")
  ),

  nav_panel(
    "6. Downloads",
    card(
      card_header("Export"),
      p("Excel workbook: W, H, allocations, per-variant summary, top traits, cutoffs, run summary, trait filtering and settings."),
      downloadButton("dl_xlsx", "Results workbook (.xlsx)"),
      downloadButton("dl_alloc", "Variant allocations (.csv)"),
      downloadButton("dl_rds", "Full R object (.rds)"),
      hr(),
      downloadButton("dl_mock_z", "Mock z-scores (.csv)"),
      downloadButton("dl_mock_n", "Mock sample sizes (.csv)")
    )
  ),

  nav_panel(
    "About",
    card(HTML(commonmark::markdown_html(readLines(file.path(app_dir, "ABOUT.md"), warn = FALSE), extensions = TRUE)))
  )
)

# ----------------------------------------------------------------------------- server
server <- function(input, output, session) {

  mock <- reactive({
    req(input$data_src == "mock")
    make_mock_bnmf_data(n_variants = input$mock_n, seed = input$mock_seed)
  })

  raw <- reactive({
    if (input$data_src == "mock") {
      m <- mock(); return(list(z = m$z, N = m$N, truth = m$truth, src = "mock"))
    }
    req(input$z_file)
    z <- tryCatch(read_wide_matrix(input$z_file$datapath),
                  error = function(e) { showNotification(conditionMessage(e), type = "error"); NULL })
    req(z)
    if (!is.null(input$n_file)) {
      N <- read_wide_matrix(input$n_file$datapath)
      common <- intersect(rownames(z), rownames(N))
      if (length(common) < nrow(z))
        showNotification(sprintf("%d variants lack N and were dropped", nrow(z) - length(common)), type = "warning")
      z <- z[common, , drop = FALSE]; N <- N[common, colnames(z), drop = FALSE]
    } else {
      N <- matrix(1, nrow(z), ncol(z), dimnames = dimnames(z))
      showNotification("No N matrix supplied: sample-size scaling is skipped (N = 1).", type = "message")
    }
    list(z = z, N = N, truth = NULL, src = "upload")
  })

  observe({
    tr <- colnames(raw()$z)
    updateSelectizeInput(session, "rm_traits", choices = tr, selected = intersect(isolate(input$rm_traits), tr))
    updateSelectizeInput(session, "keep_traits", choices = tr, selected = intersect(isolate(input$keep_traits), tr))
  })

  prep <- reactive({
    r <- raw()
    tryCatch(prep_z_matrix(r$z, r$N, corr_cutoff = input$corr_cutoff,
                           keep_my_traits = input$keep_traits, rm_traits = input$rm_traits,
                           pval_cutoff = input$pval_cutoff),
             error = function(e) { showNotification(conditionMessage(e), type = "error"); NULL })
  })

  # ---- bNMF run (button-triggered)
  res <- reactiveVal(NULL)
  observeEvent(input$run, {
    p <- prep(); req(p)
    settings <- list(n_reps = input$n_reps, K = input$K, K0 = input$K0, phi = input$phi,
                     tol = as.numeric(input$tol), n_iter = input$n_iter, seed = input$seed,
                     workers = input$workers, corr_cutoff = input$corr_cutoff,
                     pval_cutoff = p$pval_cutoff, data_src = raw()$src)
    t0 <- Sys.time()
    reps <- withProgress(message = "Running bNMF", value = 0, {
      tryCatch(
        run_bNMF_reps(p$final_z_mat, n_reps = settings$n_reps, random_seed = settings$seed,
                      K = settings$K, K0 = settings$K0, tolerance = settings$tol,
                      phi = settings$phi, n_iter = settings$n_iter, workers = settings$workers,
                      progress = function(i, n) setProgress(i / n, detail = sprintf("repetition %d / %d", i, n))),
        error = function(e) { showNotification(conditionMessage(e), type = "error", duration = NULL); NULL })
    })
    req(reps)
    s <- summarize_reps(reps)
    settings$runtime_sec <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
    res(list(reps = reps, summary = s, prep = p, settings = settings, truth = raw()$truth))
    showNotification(sprintf("bNMF finished in %.1f s: majority K = %d", settings$runtime_sec, s$majority_K),
                     type = "message")
    nav_select("main", "2. bNMF runs")
  })

  output$k_select_ui <- renderUI({
    r <- res(); req(r)
    ks <- r$summary$k_tab$K
    selectInput("k_sel", "Analyse solution with K =", choices = ks, selected = r$summary$majority_K)
  })

  wh <- reactive({
    r <- res(); req(r, input$k_sel)
    get_WH(r$reps, r$summary, as.integer(input$k_sel))
  })

  cut <- reactive({
    m <- wh()
    if (input$cut_method == "uik") {
      u <- uik_cutoff(m$W, m$H, scope = input$uik_scope, mode = input$uik_mode,
                      drop_zeros = isTRUE(input$uik_drop_zeros))
      if (anyNA(u$variant_cutoffs)) showNotification("UIK undefined for some clusters (too few non-zero weights).", type = "warning")
      u
    } else if (input$cut_method == "elbow") {
      e <- elbow_cutoff(m$W, m$H)
      cl <- colnames(m$W)
      c(e, list(mode = "global", scope = "pooled",
                variant_cutoffs = setNames(rep(e$cutoff, length(cl)), cl),
                trait_cutoffs = setNames(rep(e$cutoff, length(cl)), cl)))
    } else {
      cl <- colnames(m$W)
      list(method = "Manual", mode = "global", scope = "-", cutoff = input$manual_cut,
           variant_cutoffs = setNames(rep(input$manual_cut, length(cl)), cl),
           trait_cutoffs = setNames(rep(input$manual_cut, length(cl)), cl))
    }
  })

  alloc <- reactive(allocate_variants(wh()$W, cut()$variant_cutoffs))
  traits_top <- reactive(top_traits(wh()$H, cut()$trait_cutoffs))

  # ---- Tab 1
  output$data_boxes <- renderUI({
    r <- raw(); p <- prep(); req(p)
    layout_columns(
      value_box("Variants", nrow(r$z), theme = "primary"),
      value_box("Traits in / kept", sprintf("%d / %d", ncol(r$z), ncol(p$scaled_z)), theme = "info"),
      value_box("Missing z (set to 0)", p$n_na_replaced, theme = "secondary"),
      value_box("bNMF input", sprintf("%d \u00D7 %d", nrow(p$final_z_mat), ncol(p$final_z_mat)), theme = "success")
    )
  })
  output$trait_tbl <- renderDT({
    p <- prep(); req(p)
    datatable(p$df_traits, rownames = FALSE, options = list(pageLength = 25, dom = "tip"))
  })
  output$cor_plot <- renderPlot({
    p <- prep(); req(p)
    df <- heat_df(p$trait_cor, "t1", "t2")
    ggplot(df, aes(t2, t1, fill = value)) + geom_tile() +
      scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B", limits = c(-1, 1), name = "r") +
      labs(x = NULL, y = NULL) + theme_app +
      theme(axis.text.x = element_text(angle = 60, hjust = 1))
  })

  # ---- Tab 2
  output$k_plot <- renderPlot({
    r <- res(); req(r)
    kt <- r$summary$k_tab
    ggplot(kt, aes(factor(K), n_runs, fill = K == r$summary$majority_K)) + geom_col(width = 0.7) +
      scale_fill_manual(values = c(`TRUE` = "#18BC9C", `FALSE` = "grey70"), guide = "none") +
      labs(x = "K (active clusters)", y = "Repetitions") + theme_app
  })
  output$run_tbl <- renderDT({
    r <- res(); req(r)
    datatable(r$summary$run_tbl, rownames = FALSE, options = list(pageLength = 15, dom = "tip")) |>
      formatRound("evid", 2)
  })

  # ---- Tab 3
  output$cut_summary <- renderTable({
    cc <- cut(); a <- alloc()
    data.frame(Cluster = names(cc$variant_cutoffs),
               `Variant cutoff` = signif(cc$variant_cutoffs, 4),
               `Trait cutoff` = signif(cc$trait_cutoffs, 4),
               `Variants` = a$sizes$n_variants, check.names = FALSE)
  })
  output$cut_plot <- renderPlot({
    m <- wh(); cc <- cut()
    e <- elbow_cutoff(m$W, m$H)
    if (cc$method == "UIK" && cc$mode == "per_cluster") {
      d <- cc$curve
      kn <- d[d$knee, ]
      return(ggplot(d, aes(rank, weight)) + geom_line(colour = "grey40") +
               geom_hline(data = kn, aes(yintercept = weight), colour = "#E74C3C", linetype = 2) +
               geom_point(data = kn, colour = "#E74C3C", size = 3) +
               facet_wrap(~cluster, scales = "free") +
               labs(x = "Variant rank within cluster", y = "W weight",
                    title = "Per-cluster UIK knee (red)") + theme_app)
    }
    vals <- if (cc$method == "UIK" && cc$scope == "W") as.numeric(m$W) else c(as.numeric(m$W), as.numeric(m$H))
    if (cc$method == "UIK" && isTRUE(input$uik_drop_zeros)) vals <- vals[vals > 0]
    d <- data.frame(rank = seq_along(vals), weight = sort(vals, decreasing = TRUE))
    marks <- data.frame(label = character(), weight = numeric())
    if (cc$method == "UIK") marks <- rbind(marks, data.frame(label = "UIK knee", weight = cc$cutoff))
    if (cc$method == "manual" || cc$method == "Manual") marks <- rbind(marks, data.frame(label = "Manual", weight = cc$cutoff))
    marks <- rbind(marks, data.frame(label = "Elbow (upstream, pooled)", weight = e$cutoff))
    marks$rank <- vapply(marks$weight, function(w) max(c(1, which(d$weight >= w))), numeric(1))
    ggplot(d, aes(rank, weight)) + geom_line(colour = "grey35", linewidth = 0.8) +
      geom_hline(data = marks, aes(yintercept = weight, colour = label), linetype = 2) +
      geom_point(data = marks, aes(colour = label), size = 3.5) +
      scale_colour_manual(values = c("UIK knee" = "#E74C3C", "Elbow (upstream, pooled)" = "#3498DB",
                                     "Manual" = "#8E44AD"), name = NULL) +
      labs(x = "Rank (decreasing weight)", y = "Weight",
           subtitle = sprintf("Curve: %s (%d weights)",
                              if (cc$method == "UIK" && cc$scope == "W") "variant weights W" else "pooled W + H",
                              nrow(d))) +
      theme_app + theme(legend.position = "top")
  })

  # ---- Tab 4
  output$w_heat <- renderPlot({
    m <- wh()$W
    df <- heat_df(m, "variant", "cluster", cluster_cols = FALSE)
    ggplot(df, aes(cluster, variant, fill = value)) + geom_tile() +
      scale_fill_gradient(low = "white", high = "black", name = "Weight") +
      labs(x = "Cluster", y = sprintf("Variants (n = %d)", nrow(m))) + theme_app +
      theme(axis.text.y = element_blank(), panel.grid = element_blank())
  })
  output$h_heat <- renderPlot({
    m <- t(wh()$H)
    df <- heat_df(m, "trait", "cluster", cluster_cols = FALSE)
    ggplot(df, aes(cluster, trait, fill = value)) + geom_tile() +
      scale_fill_gradient(low = "white", high = "black", name = "Weight") +
      labs(x = "Cluster", y = NULL) + theme_app + theme(panel.grid = element_blank())
  })
  output$size_tbl <- renderTable({
    a <- alloc(); tt <- traits_top()
    a$sizes$top_traits <- vapply(a$sizes$cluster, function(k)
      paste(head(tt$trait[tt$cluster == k], 6), collapse = ", "), character(1))
    st <- table(factor(a$per_variant$status, c("single", "multiple", "unassigned")))
    rbind(transform(a$sizes, cutoff = signif(cutoff, 4)),
          data.frame(cluster = "\u2014", cutoff = NA,
                     n_variants = NA,
                     top_traits = sprintf("variants in 1 cluster: %d; >1 cluster: %d; unassigned: %d",
                                          st[["single"]], st[["multiple"]], st[["unassigned"]])))
  }, na = "")
  observe({
    cl <- colnames(wh()$W)
    updateSelectInput(session, "clus_sel", choices = cl, selected = cl[1])
  })
  output$trait_bar <- renderPlot({
    req(input$clus_sel %in% rownames(wh()$H))
    h <- wh()$H[input$clus_sel, ]
    cutv <- cut()$trait_cutoffs[[input$clus_sel]]
    df <- data.frame(trait = names(h), weight = h)
    df <- head(df[order(-df$weight), ], 15)
    df$trait <- factor(df$trait, levels = rev(df$trait))
    ggplot(df, aes(weight, trait, fill = weight >= cutv)) + geom_col() +
      geom_vline(xintercept = cutv, linetype = 2, colour = "#E74C3C") +
      scale_fill_manual(values = c(`TRUE` = "#2C3E50", `FALSE` = "grey75"),
                        labels = c(`TRUE` = "\u2265 cutoff", `FALSE` = "< cutoff"), name = NULL) +
      labs(x = "H weight", y = NULL) + theme_app + theme(legend.position = "top")
  })
  output$alloc_tbl <- renderDT({
    a <- alloc()
    datatable(a$long, rownames = FALSE, filter = "top", options = list(pageLength = 15)) |>
      formatRound(c("weight", "cutoff"), 3)
  })

  # ---- Tab 5: mock truth
  output$truth_ui <- renderUI({
    r <- res()
    if (is.null(r) || is.null(r$truth))
      return(card(p("Available after running bNMF on the mock dataset.")))
    tagList(
      layout_columns(col_widths = c(6, 6),
        card(card_header("Top cluster vs planted mechanism (all variants)"), tableOutput("conf_tbl")),
        card(card_header("Allocation accuracy at current cutoff"), tableOutput("acc_tbl"),
             helpText("Each bNMF cluster is mapped to the planted mechanism most common among its top-weighted variants. Precision = allocated (variant, cluster) pairs that are true memberships; recall = true memberships that were allocated."))
      )
    )
  })
  truth_eval <- reactive({
    r <- res(); req(r$truth)
    W <- wh()$W
    tr <- r$truth[match(rownames(W), r$truth$variant), ]
    mech <- setdiff(colnames(tr), c("variant", "true_primary", "true_secondary"))
    top <- colnames(W)[max.col(W, ties.method = "first")]
    conf <- table(`bNMF cluster` = top, `Planted mechanism` = tr$true_primary)
    map <- apply(conf, 1, function(x) colnames(conf)[which.max(x)])
    tm <- as.matrix(tr[, mech] > 0)
    list(conf = conf, map = map, tm = tm)
  })
  output$conf_tbl <- renderTable({
    te <- truth_eval()
    df <- as.data.frame.matrix(te$conf)
    cbind(Cluster = rownames(df), `Mapped to` = te$map[rownames(df)], df)
  })
  output$acc_tbl <- renderTable({
    te <- truth_eval(); pm <- alloc()$membership
    tm <- te$tm[, te$map[colnames(pm)], drop = FALSE]
    rows <- lapply(colnames(pm), function(k) {
      tp <- sum(pm[, k] & tm[, which(colnames(pm) == k)])
      data.frame(Cluster = k, Mechanism = te$map[[k]], Allocated = sum(pm[, k]),
                 `True members` = sum(tm[, which(colnames(pm) == k)]),
                 Precision = round(tp / max(1, sum(pm[, k])), 3),
                 Recall = round(tp / max(1, sum(tm[, which(colnames(pm) == k)])), 3), check.names = FALSE)
    })
    tp <- sum(pm & tm)
    rbind(do.call(rbind, rows),
          data.frame(Cluster = "All", Mechanism = "", Allocated = sum(pm), `True members` = sum(tm),
                     Precision = round(tp / max(1, sum(pm)), 3), Recall = round(tp / max(1, sum(tm)), 3),
                     check.names = FALSE))
  })

  # ---- Downloads
  output$dl_xlsx <- downloadHandler(
    filename = function() sprintf("bNMF_results_K%s_%s.xlsx", input$k_sel, format(Sys.time(), "%Y%m%d_%H%M")),
    content = function(file) {
      r <- res(); req(r); m <- wh(); cc <- cut(); a <- alloc()
      wb <- openxlsx::createWorkbook()
      add <- function(name, df) { openxlsx::addWorksheet(wb, name); openxlsx::writeData(wb, name, df) }
      add("W_variants", data.frame(variant = rownames(m$W), m$W, check.names = FALSE))
      add("H_traits", data.frame(cluster = rownames(m$H), m$H, check.names = FALSE))
      add("allocation_long", a$long)
      add("per_variant", a$per_variant)
      add("top_traits", traits_top())
      add("cutoffs", data.frame(cluster = names(cc$variant_cutoffs), variant_cutoff = cc$variant_cutoffs,
                                trait_cutoff = cc$trait_cutoffs, method = cc$method, mode = cc$mode,
                                scope = cc$scope))
      add("run_summary", r$summary$run_tbl)
      add("K_table", r$summary$k_tab)
      add("trait_filtering", r$prep$df_traits)
      add("settings", data.frame(setting = names(r$settings), value = vapply(r$settings, as.character, "")))
      openxlsx::saveWorkbook(wb, file, overwrite = TRUE)
    })
  output$dl_alloc <- downloadHandler(
    filename = function() sprintf("bNMF_allocation_K%s.csv", input$k_sel),
    content = function(file) utils::write.csv(alloc()$long, file, row.names = FALSE))
  output$dl_rds <- downloadHandler(
    filename = function() "bNMF_full_results.rds",
    content = function(file) {
      r <- res(); req(r)
      saveRDS(c(r, list(K = as.integer(input$k_sel), WH = wh(), cutoff = cut(), allocation = alloc())), file)
    })
  output$dl_mock_z <- downloadHandler("mock_z_scores.csv", function(file) {
    m <- make_mock_bnmf_data(input$mock_n, seed = input$mock_seed)
    utils::write.csv(data.frame(variant = rownames(m$z), m$z, check.names = FALSE), file, row.names = FALSE, na = "")
  })
  output$dl_mock_n <- downloadHandler("mock_sample_sizes.csv", function(file) {
    m <- make_mock_bnmf_data(input$mock_n, seed = input$mock_seed)
    utils::write.csv(data.frame(variant = rownames(m$N), m$N, check.names = FALSE), file, row.names = FALSE, na = "")
  })
}

shinyApp(ui, server)
