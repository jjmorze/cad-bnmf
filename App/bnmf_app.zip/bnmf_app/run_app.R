# Launch the app locally:  Rscript run_app.R   (opens a browser tab)
# For a LAN/web server:     Rscript run_app.R --host 0.0.0.0 --port 3838
args <- commandArgs(trailingOnly = TRUE)
get_arg <- function(flag, default) { i <- match(flag, args); if (is.na(i)) default else args[i + 1] }
script_dir <- tryCatch(dirname(normalizePath(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1]))),
                       error = function(e) getwd())
shiny::runApp(script_dir,
              host = get_arg("--host", "127.0.0.1"),
              port = as.integer(get_arg("--port", "3838")),
              launch.browser = interactive() || is.na(match("--no-browser", args)))
