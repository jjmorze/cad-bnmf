# bNMF Clustering Studio

Point-and-click Shiny app for the Bayesian NMF clustering pipeline in
[gwas-partitioning/bnmf-clustering](https://github.com/gwas-partitioning/bnmf-clustering)
(upstream commit `ed6f99b`). It runs locally or as a web app. One change from upstream:
**variants are allocated to clusters with a Unit Invariant Knee (UIK) cutoff**
(`inflection::uik`, Christopoulos 2016) instead of the two-line elbow in `calculate_cutoff()`.

## Quick start (local)
1. Install R ≥ 4.2 (https://cran.r-project.org).
2. Double-click **`Start bNMF app.command`** (macOS). Or run in a terminal:
   ```
   Rscript install_packages.R   # one time
   Rscript run_app.R            # opens http://127.0.0.1:3838
   ```
   From RStudio: open `app.R` → *Run App*.
3. Leave "Mock dataset" selected and click **Run bNMF**. Twenty repetitions take about 5 s.

## Web deployment
* Serve on your network: `Rscript run_app.R --host 0.0.0.0 --port 3838 --no-browser`
* Docker: `docker build -t bnmf-studio . && docker run -p 3838:3838 bnmf-studio`
* Shiny Server / Posit Connect / shinyapps.io: deploy this folder as-is
  (e.g. `rsconnect::deployApp(".")`).

## Input format
| File | Layout |
|---|---|
| Z-score matrix (CSV/TSV) | col 1 = variant ID; one column per trait; z aligned to the risk allele of the primary trait; blanks = missing |
| Sample-size matrix (optional) | same variant IDs and trait names; per-variant N. If you leave it out, N = 1 and no sample-size scaling is applied |

These are the `z_mat` / `N_mat` inputs of upstream `prep_z_matrix()`. Variant selection, LD
pruning, proxy lookup and allele alignment (`choose_variants_2025.R`, `prep_bNMF_2025.R`
steps before `prep_z_matrix`) happen upstream of this app.

## Pipeline
| Step | Function | Relationship to upstream |
|---|---|---|
| Trait p-value filter, correlation pruning, N scaling, ± split | `prep_z_matrix()` (R/prep.R) | same logic; no files written |
| ARD Bayesian NMF, n repetitions (optional parallel) | `BayesNMF.L2EU()`, `run_bNMF_reps()` (R/bnmf_core.R) | same update rules, priors, λ cut and convergence |
| K summary, MAP run per K | `summarize_reps()`, `get_WH()` | same as `summarize_bNMF()` |
| **Allocation cutoff** | `uik_cutoff()` (R/cutoff.R) | **new**: UIK knee on the rank-ordered weight curve |
| Upstream elbow, for comparison | `elbow_cutoff()` | port of `calculate_cutoff()` |
| Soft allocation, top traits | `allocate_variants()`, `top_traits()` | W ≥ cutoff, as in upstream PRS weight files |

UIK options (tab 3):
* **Global, W (default)**: one knee on all variant weights in W.
* **Global, pooled W + H**: the same pooled curve the upstream elbow uses.
* **Per cluster**: a separate knee for each W column (variants) and each H row (traits).
* Optionally leave exact zeros out of the curve.

## Mock dataset
`R/mock_data.R` simulates 300 variants × 20 traits with 5 planted mechanisms (BetaCell,
Proinsulin, Obesity, Lipodystrophy, LiverLipid); 15 % of variants act through two of them.
It also includes a BMI near-duplicate (WC), which correlation pruning removes, a pure-noise
trait, which the p-value filter removes, about 3 % missing z-scores, and variable N.
Pre-generated CSVs are in `data/` (`mock_truth.csv` holds the planted memberships).

## Tests
```
Rscript tests/test_pipeline.R   # end-to-end; writes tests/mock_validation.csv
Rscript tests/test_server.R     # drives every Shiny output headlessly
```
Mock results (seed 7, 20 repetitions): K = 5 in 15/20 runs. The top-weight cluster matches the
planted mechanism for 94.7 % of variants.

| Cutoff | Value | Variants assigned | Precision | Recall |
|---|---|---|---|---|
| UIK global W | 0.350 | 293/300 | 0.922 | 0.940 |
| UIK per cluster | 0.27–0.35 | 295/300 | 0.878 | 0.969 |
| UIK global pooled W+H | 1.32 | 89/300 | 1.000 | 0.257 |
| Elbow (upstream) | 1.10 | 143/300 | 1.000 | 0.417 |

H weights in the pooled curve are larger than W weights, so any knee or elbow placed on the
pooled curve gives a strict variant cutoff. The UIK default therefore uses W alone. These
numbers come from synthetic data; check the choice on your real data.
