# =============================================================================
# cutoff.R
# Weight cutoffs used to allocate variants (and traits) to bNMF clusters.
#
#  * uik_cutoff()   - NEW: Unit Invariant Knee (Christopoulos 2016,
#                     inflection::uik) on the rank-ordered weight curve.
#  * elbow_cutoff() - upstream calculate_cutoff() (post_bNMF_2025.R): the
#                     intersection-of-two-lines elbow (top 1%/5% vs bottom 80%),
#                     kept for side-by-side comparison.
#
# Both operate on the same curve as upstream: all W and H weights pooled,
# sorted in decreasing order, x = rank. UIK is invariant to the units of x
# and y, so no rescaling is needed.
# =============================================================================

# Core UIK on a vector of weights. Returns cutoff (= weight at the knee).
uik_on_weights <- function(w, drop_zeros = FALSE) {
  w <- as.numeric(w)
  w <- w[is.finite(w)]
  if (drop_zeros) w <- w[w > 0]
  w <- sort(w, decreasing = TRUE)
  if (length(w) < 5 || length(unique(w)) < 3) {
    return(list(cutoff = NA_real_, knee_rank = NA_integer_,
                curve = data.frame(rank = seq_along(w), weight = w)))
  }
  x <- seq_along(w)
  knee_x <- inflection::uik(x, w)
  k <- as.integer(round(knee_x))
  list(cutoff = w[k], knee_rank = k,
       curve = data.frame(rank = x, weight = w))
}

# Global or per-cluster UIK cutoff.
#   scope = "pooled": W and H weights pooled (mirrors upstream input curve)
#   scope = "W"     : variant weights only
#   mode  = "global": one cutoff for all clusters
#   mode  = "per_cluster": UIK computed on each W column (variants) and each
#           H row (traits) separately
uik_cutoff <- function(W, H, scope = c("pooled", "W"), mode = c("global", "per_cluster"),
                       drop_zeros = FALSE) {
  scope <- match.arg(scope); mode <- match.arg(mode)
  if (mode == "global") {
    vals <- if (scope == "pooled") c(as.numeric(W), as.numeric(H)) else as.numeric(W)
    u <- uik_on_weights(vals, drop_zeros = drop_zeros)
    cl <- colnames(W)
    return(list(method = "UIK", mode = mode, scope = scope,
                cutoff = u$cutoff,
                variant_cutoffs = setNames(rep(u$cutoff, length(cl)), cl),
                trait_cutoffs = setNames(rep(u$cutoff, length(cl)), cl),
                knee_rank = u$knee_rank, curve = u$curve))
  }
  cl <- colnames(W)
  vres <- lapply(cl, function(k) uik_on_weights(W[, k], drop_zeros = drop_zeros))
  tres <- lapply(cl, function(k) uik_on_weights(H[k, ], drop_zeros = drop_zeros))
  curves <- do.call(rbind, lapply(seq_along(cl), function(i)
    cbind(vres[[i]]$curve, cluster = cl[i],
          knee = vres[[i]]$curve$rank == vres[[i]]$knee_rank)))
  list(method = "UIK", mode = mode, scope = "W (per cluster)",
       cutoff = NA_real_,
       variant_cutoffs = setNames(vapply(vres, `[[`, numeric(1), "cutoff"), cl),
       trait_cutoffs = setNames(vapply(tres, `[[`, numeric(1), "cutoff"), cl),
       knee_rank = setNames(vapply(vres, function(r) as.integer(r$knee_rank), integer(1)), cl),
       curve = curves)
}

# Upstream elbow method (calculate_cutoff in post_bNMF_2025.R), without the
# side-effect ggsave(); returns the curve so the GUI can plot it.
elbow_cutoff <- function(W, H) {
  dist_point_line <- function(a, slope, intercept) {
    b <- c(1, intercept + slope); c0 <- c(0, intercept)
    v1 <- b - c0; v2 <- a - b
    abs(det(cbind(v1, v2))) / sqrt(sum(v1 * v1))
  }
  weight <- sort(c(as.numeric(W), as.numeric(H)), decreasing = TRUE)
  n_w <- length(weight)
  d <- data.frame(weight = weight, x = seq_len(n_w))
  d$x_scale <- d$x / n_w
  d$w_scale <- d$weight / max(d$weight)
  cutoff_test <- quantile(d$weight, prob = 1 - 1 / 100)
  n <- ifelse(sum(d$weight > cutoff_test) > 3, 1, 5)
  m <- 80
  top <- d[d$weight > quantile(d$weight, prob = 1 - n / 100), ]
  low <- d[d$weight <= quantile(d$weight, prob = m / 100), ]
  d$group <- ifelse(d$x %in% top$x, paste0("top", n),
                    ifelse(d$x %in% low$x, paste0("bottom", m), "other"))
  top_line <- lm(w_scale ~ x_scale, data = top)
  low_line <- lm(w_scale ~ x_scale, data = low)
  d$dist_top <- vapply(seq_len(n_w), function(i)
    dist_point_line(c(d$x_scale[i], d$w_scale[i]), coef(top_line)[2], coef(top_line)[1]), numeric(1))
  d$dist_low <- vapply(seq_len(n_w), function(i)
    dist_point_line(c(d$x_scale[i], d$w_scale[i]), coef(low_line)[2], coef(low_line)[1]), numeric(1))
  d$diff <- d$dist_top - d$dist_low
  cut <- d[d$diff > 0, ]
  list(method = "Elbow (upstream)", cutoff = cut$weight[1], knee_rank = cut$x[1], curve = d,
       top_line = coef(top_line), low_line = coef(low_line))
}

# Allocate variants (rows of W) to clusters with weight >= cluster cutoff.
# Soft clustering: a variant can belong to >1 cluster, or to none.
allocate_variants <- function(W, cutoffs) {
  cl <- colnames(W)
  if (length(cutoffs) == 1) cutoffs <- setNames(rep(cutoffs, length(cl)), cl)
  cutoffs <- cutoffs[cl]
  memb <- sweep(W, 2, cutoffs, `>=`)
  memb[is.na(memb)] <- FALSE
  long <- do.call(rbind, lapply(cl, function(k) {
    idx <- which(memb[, k])
    if (!length(idx)) return(NULL)
    data.frame(variant = rownames(W)[idx], cluster = k, weight = W[idx, k],
               cutoff = cutoffs[[k]], stringsAsFactors = FALSE)
  }))
  if (is.null(long)) long <- data.frame(variant = character(), cluster = character(),
                                        weight = numeric(), cutoff = numeric())
  long <- long[order(long$cluster, -long$weight), ]
  per_variant <- data.frame(
    variant = rownames(W),
    top_cluster = cl[max.col(W, ties.method = "first")],
    top_weight = apply(W, 1, max),
    n_clusters = rowSums(memb),
    clusters = apply(memb, 1, function(r) paste(cl[r], collapse = ";")),
    stringsAsFactors = FALSE
  )
  per_variant$status <- ifelse(per_variant$n_clusters == 0, "unassigned",
                         ifelse(per_variant$n_clusters == 1, "single", "multiple"))
  sizes <- data.frame(cluster = cl, cutoff = as.numeric(cutoffs),
                      n_variants = colSums(memb), stringsAsFactors = FALSE)
  list(long = long, per_variant = per_variant, membership = memb, sizes = sizes)
}

# Traits (columns of H) with weight >= cutoff in each cluster.
top_traits <- function(H, cutoffs) {
  cl <- rownames(H)
  if (length(cutoffs) == 1) cutoffs <- setNames(rep(cutoffs, length(cl)), cl)
  out <- do.call(rbind, lapply(cl, function(k) {
    h <- H[k, ]
    idx <- which(h >= cutoffs[[k]])
    if (!length(idx)) return(NULL)
    data.frame(cluster = k, trait = names(h)[idx], weight = h[idx], stringsAsFactors = FALSE)
  }))
  if (is.null(out)) return(data.frame(cluster = character(), trait = character(), weight = numeric()))
  out[order(out$cluster, -out$weight), ]
}
