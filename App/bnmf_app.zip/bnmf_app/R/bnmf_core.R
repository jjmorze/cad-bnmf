# =============================================================================
# bnmf_core.R
# Core Bayesian NMF (ARD, L2/Euclidean) - ported from
#   gwas-partitioning/bnmf-clustering  scripts/run_bNMF_2025.R
# The update equations, priors, lambda cut and convergence rules are kept
# identical to the upstream BayesNMF.L2EU(); only console printing was made
# optional and a per-repetition progress callback was added for the GUI.
#
# Copyright (c) 2017, Broad Institute (original algorithm code; BSD-3 licence
# reproduced in LICENSE_bnmf_upstream.txt).
# Udler MS et al. PLoS Med 2018; Tan & Fevotte, IEEE TPAMI 2013.
# =============================================================================

BayesNMF.L2EU <- function(V0, n.iter = 10000, a0 = 10, tol = 1e-7, K = 15, K0 = 15,
                          phi = 1.0, window_size = 25, min_iter = 100, verbose = FALSE) {
  eps <- 1.e-50
  del <- 1.0
  active_nodes <- colSums(V0) != 0
  V0 <- V0[, active_nodes, drop = FALSE]
  V <- V0 - min(V0)
  Vmin <- min(V)
  Vmax <- max(V)
  N <- dim(V)[1]
  M <- dim(V)[2]

  W <- matrix(runif(N * K) * Vmax, ncol = K)
  H <- matrix(runif(M * K) * Vmax, ncol = M)
  rownames(W) <- rownames(V)
  colnames(H) <- colnames(V)
  lambda_matrix_M <- matrix(0, nrow = K, ncol = M)
  lambda_matrix_N <- matrix(0, nrow = K, ncol = N)

  V.ap <- W %*% H + eps

  phi <- sd(V)^2 * phi
  C <- (N + M) / 2 + a0 + 1
  b0 <- 3.14 * (a0 - 1) * mean(V) / (2 * K0)
  lambda.bound <- b0 / C
  lambda <- (0.5 * colSums(W^2) + 0.5 * rowSums(H^2) + b0) / C
  lambda.cut <- lambda.bound * 1.5

  n.like <- list(); n.evid <- list(); n.error <- list()
  n.lambda <- list(); n.active <- list()
  n.lambda[[1]] <- lambda

  check_convergence <- function(errors, window_size) {
    if (length(errors) < window_size) return(FALSE)
    recent <- tail(unlist(errors), window_size)
    rel_change <- abs(mean(diff(recent)) / mean(recent))
    rel_change < tol
  }

  iter <- 2
  while ((iter <= min_iter || del >= tol) && iter < n.iter) {
    lambda_matrix_M[] <- rep(1 / lambda, M)
    lambda_matrix_N[] <- rep(1 / lambda, N)

    H <- H * (t(W) %*% V) / (t(W) %*% V.ap + phi * H * lambda_matrix_M + eps)
    V.ap <- W %*% H + eps
    W <- W * (V %*% t(H)) / (V.ap %*% t(H) + phi * W * t(lambda_matrix_N) + eps)
    V.ap <- W %*% H + eps

    lambda <- (0.5 * colSums(W^2) + 0.5 * rowSums(H^2) + b0) / C
    lambda[is.na(lambda)] <- 1e-6
    lambda[is.nan(lambda)] <- 1e-6
    lambda[lambda == Inf] <- 1e-6

    del <- if (!is.null(n.lambda[[iter - 1]]) && all(is.finite(n.lambda[[iter - 1]]))) {
      max(abs(lambda - n.lambda[[iter - 1]]) / (n.lambda[[iter - 1]] + 1e-10))
    } else Inf

    like <- sum((V - V.ap)^2) / 2
    n.like[[iter]] <- like
    n.evid[[iter]] <- like + phi * sum((0.5 * colSums(W^2) + 0.5 * rowSums(H^2) + b0) /
                                         lambda + C * log(lambda))
    n.error[[iter]] <- sum((V - V.ap)^2)
    n.lambda[[iter]] <- lambda
    n.active[[iter]] <- sum(lambda >= lambda.cut)

    if (verbose && iter %% 100 == 0) {
      cat(sprintf("Iter %d: Error=%g, Delta=%g, Active=%d, Evidence=%g\n",
                  iter, n.error[[iter]], del, n.active[[iter]], n.evid[[iter]]))
    }
    if (iter > min_iter && iter %% 20 == 0) {
      if (check_convergence(n.error, window_size)) break
    }
    iter <- iter + 1
  }

  final_active_components <- which(lambda >= lambda.cut)
  if (length(final_active_components) == 0L) stop("bNMF ended without any active components.")

  list(W = W, H = H,
       n.like = n.like, n.evid = n.evid, n.lambda = n.lambda,
       n.error = n.error, n.active = n.active,
       lambda_cut = lambda.cut, active_components = final_active_components,
       iterations = iter - 1, converged = del < tol)
}

# Run n_reps repetitions. workers > 1 uses future/furrr (multisession), as in
# upstream run_bNMF_parallel(); workers == 1 runs sequentially and reports
# progress through `progress(i, n)`.
run_bNMF_reps <- function(z_mat, n_reps = 10, random_seed = 1, K = 20, K0 = 10,
                          tolerance = 1e-7, phi = 1, n_iter = 10000,
                          workers = 1, progress = NULL) {
  workers <- min(as.integer(workers), max(1L, as.integer(parallelly::availableCores()) - 0L))
  if (workers > 1) {
    future::plan(future::multisession, workers = workers)
    on.exit(future::plan(future::sequential), add = TRUE)
    if (!is.null(progress)) progress(0, n_reps)
    reps <- furrr::future_map(seq_len(n_reps), function(r) {
      BayesNMF.L2EU(V0 = z_mat, K = K, K0 = K0, tol = tolerance, phi = phi, n.iter = n_iter)
    }, .options = furrr::furrr_options(seed = random_seed,
                                        globals = list(BayesNMF.L2EU = BayesNMF.L2EU,
                                                       z_mat = z_mat, K = K, K0 = K0,
                                                       tolerance = tolerance, phi = phi,
                                                       n_iter = n_iter)))
    if (!is.null(progress)) progress(n_reps, n_reps)
  } else {
    set.seed(random_seed)
    reps <- vector("list", n_reps)
    for (r in seq_len(n_reps)) {
      reps[[r]] <- BayesNMF.L2EU(V0 = z_mat, K = K, K0 = K0, tol = tolerance,
                                 phi = phi, n.iter = n_iter)
      if (!is.null(progress)) progress(r, n_reps)
    }
  }
  reps
}

# Equivalent of upstream summarize_bNMF()'s make_run_summary(): K per run,
# final evidence (-log posterior), and the MAP (min-evidence) run for each K.
summarize_reps <- function(reps) {
  run_tbl <- data.frame(
    run = seq_along(reps),
    K = vapply(reps, function(r) length(r$active_components), integer(1)),
    evid = vapply(reps, function(r) r$n.evid[[length(r$n.evid)]], numeric(1)),
    iterations = vapply(reps, function(r) as.integer(r$iterations), integer(1)),
    converged = vapply(reps, function(r) isTRUE(r$converged), logical(1))
  )
  run_tbl <- run_tbl[order(run_tbl$evid), ]
  k_tab <- as.data.frame(table(K = run_tbl$K), stringsAsFactors = FALSE)
  k_tab$K <- as.integer(k_tab$K)
  names(k_tab)[2] <- "n_runs"
  k_tab$fraction <- k_tab$n_runs / length(reps)
  k_tab$MAP_run <- vapply(k_tab$K, function(k) {
    tmp <- run_tbl[run_tbl$K == k, ]
    tmp$run[which.min(tmp$evid)]
  }, integer(1))
  k_tab$MAP_evid <- vapply(k_tab$K, function(k) min(run_tbl$evid[run_tbl$K == k]), numeric(1))
  majority_K <- k_tab$K[which.max(k_tab$n_runs)]
  list(run_tbl = run_tbl, k_tab = k_tab, majority_K = majority_K)
}

# Extract W (variants x K) and H (K x 2M traits) for the MAP run at a given K,
# exactly as upstream summarize_bNMF() writes L2EU.W.mat.K / L2EU.H.mat.K.
get_WH <- function(reps, summary, k) {
  run <- summary$k_tab$MAP_run[summary$k_tab$K == k]
  if (length(run) != 1) stop("No bNMF run produced K = ", k)
  res <- reps[[run]]
  active <- res$active_components
  W <- res$W[, active, drop = FALSE]
  H <- res$H[active, , drop = FALSE]
  nm <- paste0("X", seq_along(active))
  colnames(W) <- nm
  rownames(H) <- nm
  W[W < 1.e-10] <- 0
  H[H < 1.e-10] <- 0
  list(W = W, H = H, run = run)
}
