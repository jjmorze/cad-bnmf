# =============================================================================
# mock_data.R
# Simulated multi-trait GWAS z-score matrix with planted pathway structure,
# for checking that the app runs end-to-end and recovers known clusters.
#
# Design (defaults):
#   * 300 variants, aligned to the risk-increasing allele of a primary trait
#     ("T2D"), so T2D z-scores are positive.
#   * 5 latent mechanisms, each with a signed trait signature
#     (BetaCell, Proinsulin, Obesity, Lipodystrophy, LiverLipid).
#   * ~85% of variants act through one mechanism, ~15% through two.
#   * Extra traits that exercise prep_z_matrix():
#       - "WC"          : near-duplicate of BMI  -> removed by correlation pruning
#       - "Null_trait"  : pure noise             -> removed by the p-value filter
#   * Per-variant sample sizes vary around trait-specific medians; ~3% of z
#     values are missing (NA).
# =============================================================================

make_mock_bnmf_data <- function(n_variants = 300, noise_sd = 1.2, het_sd = 0.35, t2d_load = 4, seed = 7) {
  set.seed(seed)
  traits <- c("T2D", "FastingInsulin", "FastingGlucose", "Proinsulin", "HOMA_B",
              "BMI", "WC", "BodyFat", "WHRadjBMI", "HDL", "TG", "Adiponectin",
              "ALT", "GGT", "LDL", "SHBG", "CRP", "HbA1c", "AIR", "Null_trait")
  mech <- c("BetaCell", "Proinsulin", "Obesity", "Lipodystrophy", "LiverLipid")

  # signed mechanism -> trait signatures (expected z per unit of mechanism activity)
  S <- matrix(0, nrow = length(mech), ncol = length(traits), dimnames = list(mech, traits))
  S["BetaCell", c("T2D", "FastingGlucose", "HOMA_B", "HbA1c", "AIR", "Proinsulin")] <- c(4, 5, -4, 3.5, -4.5, 1.5)
  S["Proinsulin", c("T2D", "Proinsulin", "FastingInsulin", "HOMA_B", "AIR")] <- c(4, -7, -2, 2, 1.5)
  S["Obesity", c("T2D", "BMI", "WC", "BodyFat", "FastingInsulin", "CRP", "TG")] <- c(4, 6, 5.8, 3.5, 2.5, 3, 1)
  S["Lipodystrophy", c("T2D", "FastingInsulin", "WHRadjBMI", "HDL", "TG", "Adiponectin", "BMI", "BodyFat")] <-
    c(4, 4, 4, -4, 3, -3.5, -2, -3.5)
  S["LiverLipid", c("T2D", "ALT", "GGT", "TG", "LDL", "SHBG", "CRP", "HbA1c")] <- c(4, 5, 3.5, -3, -4, -2, 2, -1.5)
  S[, "T2D"] <- t2d_load

  # variant -> mechanism activities
  n_mech <- length(mech)
  ids <- sprintf("chr%d:%d_A_G", sample(1:22, n_variants, TRUE),
                 1e6 + sample.int(2e8, n_variants))
  ids <- make.unique(ids)
  A <- matrix(0, n_variants, n_mech, dimnames = list(ids, mech))
  primary <- sample(seq_len(n_mech), n_variants, replace = TRUE, prob = c(0.2, 0.2, 0.22, 0.2, 0.18))
  for (i in seq_len(n_variants)) {
    A[i, primary[i]] <- rgamma(1, shape = 4, rate = 4) + 0.4
    if (runif(1) < 0.15) {
      sec <- sample(setdiff(seq_len(n_mech), primary[i]), 1)
      A[i, sec] <- rgamma(1, shape = 3, rate = 5) + 0.3
    }
  }

  z <- A %*% S
  # variant-specific effect heterogeneity + sampling noise
  z <- z + z * matrix(rnorm(length(z), sd = het_sd), nrow(z)) +
    matrix(rnorm(length(z), sd = noise_sd), nrow(z))
  # WC = near copy of BMI (r > 0.85) ; Null trait = pure noise
  z[, "WC"] <- z[, "BMI"] * 0.95 + rnorm(n_variants, sd = 0.4)
  z[, "Null_trait"] <- rnorm(n_variants, sd = 1)
  # alignment: T2D risk allele -> keep T2D positive
  flip <- z[, "T2D"] < 0
  z[flip, ] <- -z[flip, ]
  A_true <- A

  # sample sizes
  medN <- setNames(round(runif(length(traits), 2e4, 6e5)), traits)
  N <- sapply(traits, function(t) round(medN[t] * runif(n_variants, 0.7, 1.0)))
  rownames(N) <- rownames(z)
  # rescale z so that larger-N traits carry proportionally larger |z|
  z <- z * sqrt(sweep(N, 2, medN, "/"))

  # missingness
  miss <- matrix(runif(length(z)) < 0.03, nrow(z), dimnames = dimnames(z))
  miss[, "T2D"] <- FALSE
  z[miss] <- NA
  N[miss] <- NA

  truth <- data.frame(variant = rownames(A_true),
                      true_primary = mech[primary],
                      true_secondary = apply(A_true, 1, function(r) {
                        s <- names(r)[r > 0]; s <- setdiff(s, names(which.max(r)))
                        if (length(s)) s else NA_character_ }),
                      stringsAsFactors = FALSE)
  truth <- cbind(truth, A_true)
  list(z = z, N = N, truth = truth, signatures = S)
}

write_mock_bnmf_data <- function(dir, ...) {
  d <- make_mock_bnmf_data(...)
  dir.create(dir, showWarnings = FALSE, recursive = TRUE)
  out_z <- data.frame(variant = rownames(d$z), d$z, check.names = FALSE)
  out_N <- data.frame(variant = rownames(d$N), d$N, check.names = FALSE)
  utils::write.csv(out_z, file.path(dir, "mock_z_scores.csv"), row.names = FALSE, na = "")
  utils::write.csv(out_N, file.path(dir, "mock_sample_sizes.csv"), row.names = FALSE, na = "")
  utils::write.csv(d$truth, file.path(dir, "mock_truth.csv"), row.names = FALSE, na = "")
  utils::write.csv(data.frame(mechanism = rownames(d$signatures), d$signatures, check.names = FALSE),
                   file.path(dir, "mock_signatures.csv"), row.names = FALSE)
  invisible(d)
}
