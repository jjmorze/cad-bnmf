# =============================================================================
# prep.R
# Final pre-processing before bNMF - adapted from upstream prep_z_matrix()
# (scripts/prep_bNMF_2025.R). Logic is unchanged; file writes were removed and
# the steps are returned as data so the GUI can display them.
#   1) optional manual trait removal
#   2) drop traits with no variant at p < pval_cutoff (default 0.05/N_variants)
#   3) greedy correlation pruning (|r| >= corr_cutoff), traits ranked by max(z)
#   4) z / sqrt(N) * mean(sqrt(median N per trait))
#   5) NA -> 0, expand to N x 2M non-negative matrix (_pos / _neg)
# =============================================================================

prep_z_matrix <- function(z_mat, N_mat, corr_cutoff = 0.85, keep_my_traits = NULL,
                          rm_traits = NULL, pval_cutoff = NULL, nonneg = TRUE) {
  z_mat <- as.matrix(z_mat); N_mat <- as.matrix(N_mat)
  stopifnot(identical(rownames(z_mat), rownames(N_mat)))
  missing_N <- setdiff(colnames(z_mat), colnames(N_mat))
  if (length(missing_N)) stop("N matrix lacks traits: ", paste(missing_N, collapse = ", "))

  z_mat_orig <- z_mat
  if (is.null(pval_cutoff) || is.na(pval_cutoff)) pval_cutoff <- 0.05 / nrow(z_mat)
  n_missing_start <- sum(is.na(z_mat))
  df_traits <- data.frame(trait = colnames(z_mat), stringsAsFactors = FALSE)
  filt <- data.frame(trait = character(), result = character(), note = character())

  if (length(rm_traits)) {
    z_mat <- z_mat[, !colnames(z_mat) %in% rm_traits, drop = FALSE]
    filt <- rbind(filt, data.frame(trait = rm_traits, result = "removed (manual)", note = NA))
  }

  minP_vec <- apply(z_mat, 2, function(x) min(2 * pnorm(abs(x), lower.tail = FALSE), na.rm = TRUE))
  low <- minP_vec >= pval_cutoff
  if (any(low)) {
    filt <- rbind(filt, data.frame(trait = colnames(z_mat)[low], result = "removed (p-value)",
                                   note = paste("min pval=", format(minP_vec[low], scientific = TRUE))))
  }
  z_mat <- z_mat[, !low, drop = FALSE]
  if (ncol(z_mat) < 2) stop("Fewer than 2 traits pass the p-value filter.")

  trait_cor_mat_full <- cor(z_mat, use = "pairwise.complete.obs")
  trait_cor_mat <- trait_cor_mat_full
  remaining <- names(sort(apply(z_mat, 2, max, na.rm = TRUE), decreasing = TRUE))
  keep_traits <- c()
  while (length(remaining) > 0) {
    keep_traits <- c(keep_traits, remaining[1])
    if (length(remaining) == 1) break
    trait_cor_mat <- trait_cor_mat[remaining, remaining, drop = FALSE]
    to_remove <- rownames(trait_cor_mat)[abs(trait_cor_mat[, remaining[1]]) >= corr_cutoff]
    if (length(to_remove) > 1) {
      filt <- rbind(filt, data.frame(trait = setdiff(to_remove, remaining[1]),
                                     result = "removed (correlation)",
                                     note = paste("correlated w/", remaining[1])))
    }
    remaining <- setdiff(remaining, to_remove)
  }
  keep_traits <- unique(c(keep_traits, keep_my_traits))
  z_mat <- z_mat_orig[, keep_traits, drop = FALSE]

  df_traits <- merge(df_traits, filt, by = "trait", all.x = TRUE, sort = FALSE)
  df_traits$result[is.na(df_traits$result)] <- "trait kept"
  df_traits$result[df_traits$trait %in% keep_my_traits] <- "trait kept (manual)"

  medN_vec <- apply(N_mat[, colnames(z_mat), drop = FALSE], 2, median, na.rm = TRUE)
  z_mat <- z_mat / sqrt(N_mat[, colnames(z_mat), drop = FALSE]) * mean(sqrt(medN_vec))
  n_na_replaced <- sum(is.na(z_mat))
  z_mat[is.na(z_mat)] <- 0
  scaled_z <- z_mat

  if (nonneg) {
    z_pos <- z_mat; z_pos[z_pos < 0] <- 0; colnames(z_pos) <- paste0(colnames(z_mat), "_pos")
    z_neg <- -z_mat; z_neg[z_neg < 0] <- 0; colnames(z_neg) <- paste0(colnames(z_mat), "_neg")
    final_z_mat <- cbind(z_pos, z_neg)
  } else final_z_mat <- z_mat

  list(final_z_mat = final_z_mat, scaled_z = scaled_z, df_traits = df_traits,
       trait_cor = trait_cor_mat_full, pval_cutoff = pval_cutoff,
       n_missing_start = n_missing_start, n_na_replaced = n_na_replaced)
}

# Read a wide matrix CSV/TSV: first column = variant ID, remaining = traits.
read_wide_matrix <- function(path) {
  sep <- if (grepl("\\.(tsv|txt)(\\.gz)?$", path, ignore.case = TRUE)) "\t" else ","
  df <- utils::read.delim(path, sep = sep, check.names = FALSE, stringsAsFactors = FALSE)
  ids <- as.character(df[[1]])
  if (anyDuplicated(ids)) stop("Duplicated variant IDs in ", basename(path))
  m <- as.matrix(df[, -1, drop = FALSE])
  storage.mode(m) <- "double"
  rownames(m) <- ids
  m
}
