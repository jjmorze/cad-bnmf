# Headless end-to-end check on the mock dataset:  Rscript tests/test_pipeline.R
app_root <- normalizePath(file.path(dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1])), ".."))
for (f in list.files(file.path(app_root, "R"), full.names = TRUE)) source(f)
d <- make_mock_bnmf_data(n_variants = 300, seed = 7)
p <- prep_z_matrix(d$z, d$N)
stopifnot(any(c("WC", "BMI") %in% p$df_traits$trait[p$df_traits$result == "removed (correlation)"]),
          "Null_trait" %in% p$df_traits$trait[p$df_traits$result == "removed (p-value)"])
reps <- run_bNMF_reps(p$final_z_mat, n_reps = 20, K = 20, K0 = 10, random_seed = 1)
s <- summarize_reps(reps)
print(s$k_tab)
mech <- c("BetaCell", "Proinsulin", "Obesity", "Lipodystrophy", "LiverLipid")
res <- do.call(rbind, lapply(s$k_tab$K, function(k) {
  wh <- get_WH(reps, s, k)
  tr <- d$truth[match(rownames(wh$W), d$truth$variant), ]
  top <- colnames(wh$W)[max.col(wh$W)]
  conf <- table(top, tr$true_primary)
  map <- apply(conf, 1, function(x) colnames(conf)[which.max(x)])
  tm <- as.matrix(tr[, mech] > 0)[, map[colnames(wh$W)], drop = FALSE]
  methods <- list(
    "UIK global W"      = uik_cutoff(wh$W, wh$H, scope = "W")$variant_cutoffs,
    "UIK global pooled" = uik_cutoff(wh$W, wh$H, scope = "pooled")$variant_cutoffs,
    "UIK per cluster"   = uik_cutoff(wh$W, wh$H, mode = "per_cluster")$variant_cutoffs,
    "Elbow (upstream)"  = elbow_cutoff(wh$W, wh$H)$cutoff)
  do.call(rbind, lapply(names(methods), function(m) {
    pm <- allocate_variants(wh$W, methods[[m]])$membership
    tp <- sum(pm & tm)
    data.frame(K = k, runs = s$k_tab$n_runs[s$k_tab$K == k], method = m,
               cutoff = paste(signif(unique(methods[[m]]), 3), collapse = "/"),
               assigned = sum(rowSums(pm) > 0), unassigned = sum(rowSums(pm) == 0),
               precision = round(tp / sum(pm), 3), recall = round(tp / sum(tm), 3),
               top_cluster_purity = round(sum(apply(conf, 1, max)) / sum(conf), 3))
  }))
}))
print(res, row.names = FALSE)
out <- file.path(app_root, "tests", "mock_validation.csv")
write.csv(res, out, row.names = FALSE)
cat("PASS — wrote", out, "\n")
