# Drives the Shiny server headlessly (shiny::testServer) on the mock dataset.
suppressPackageStartupMessages(library(shiny))
app_root <- normalizePath(file.path(dirname(sub("--file=", "", grep("--file=", commandArgs(), value = TRUE)[1])), ".."))
app <- shinyAppDir(app_root)
testServer(app, {
  session$setInputs(data_src = "mock", mock_n = 300, mock_seed = 7, pval_cutoff = NA, corr_cutoff = 0.85,
                    rm_traits = NULL, keep_traits = NULL, n_reps = 12, K = 20, K0 = 10, phi = 1,
                    tol = "1e-7", n_iter = 10000, seed = 1, workers = 1,
                    cut_method = "uik", uik_mode = "global", uik_scope = "W", uik_drop_zeros = FALSE,
                    manual_cut = 0.5)
  stopifnot(ncol(prep()$final_z_mat) == 2 * ncol(prep()$scaled_z))
  session$setInputs(run = 1)
  r <- res(); stopifnot(!is.null(r))
  cat("majority K:", r$summary$majority_K, "\n")
  session$setInputs(k_sel = as.character(r$summary$majority_K), clus_sel = "X1")
  for (o in c("data_boxes", "trait_tbl", "cor_plot", "k_plot", "run_tbl", "cut_summary", "cut_plot",
              "w_heat", "h_heat", "size_tbl", "trait_bar", "alloc_tbl", "truth_ui", "conf_tbl", "acc_tbl"))
    invisible(output[[o]])
  cat("UIK (global, W) cutoff:", signif(cut()$cutoff, 4), "\n")
  print(alloc()$sizes)
  cat(output$acc_tbl, "\n")
  for (cfg in list(list("uik", "per_cluster", "W"), list("uik", "global", "pooled"),
                   list("elbow", "global", "W"), list("manual", "global", "W"))) {
    session$setInputs(cut_method = cfg[[1]], uik_mode = cfg[[2]], uik_scope = cfg[[3]])
    invisible(output$cut_plot); invisible(output$size_tbl)
    cat(sprintf("%-6s %-11s %-6s -> cutoffs %s | assigned %d\n", cfg[[1]], cfg[[2]], cfg[[3]],
                paste(signif(cut()$variant_cutoffs, 3), collapse = "/"),
                sum(alloc()$per_variant$n_clusters > 0)))
  }
  session$setInputs(cut_method = "uik", uik_mode = "global", uik_scope = "W")
  f <- output$dl_xlsx
  cat("xlsx sheets:", paste(openxlsx::getSheetNames(f), collapse = ", "), "\n")
  cat("rds bytes:", file.size(output$dl_rds), "\n")
})
cat("SERVER TEST PASS\n")
