## bNMF Clustering Studio

A graphical front-end for the Bayesian non-negative matrix factorisation (bNMF) clustering
pipeline from [gwas-partitioning/bnmf-clustering](https://github.com/gwas-partitioning/bnmf-clustering)
(upstream commit `ed6f99b`), with one methodological change: **variants are allocated to clusters
using a Unit Invariant Knee (UIK) cutoff** instead of the upstream two-line elbow.

### Workflow
1. **Input** — a variants × traits z-score matrix (aligned to the risk allele of the primary trait)
   and, optionally, a matching per-variant sample-size matrix.
2. **Pre-processing** (`prep_z_matrix`, unchanged logic): remove traits with no variant at
   p < 0.05/N; greedy correlation pruning (|r| ≥ 0.85 by default, traits ranked by max z);
   z / √N × mean(√median N); missing → 0; split into non-negative `_pos` / `_neg` columns (N × 2M).
3. **bNMF** (`BayesNMF.L2EU`, unchanged update rules): L2/Euclidean NMF with an automatic-relevance-
   determination prior, repeated *n* times from random starts. K = number of components whose
   relevance λ exceeds 1.5 × the prior bound. The majority K is the default solution; within each K
   the run with the lowest evidence (−log posterior) is used.
4. **Cutoff** — rank all weights in decreasing order and locate the knee with
   `inflection::uik()` (Christopoulos 2016). The cutoff is the weight at the knee.
   * *Global, W*: one knee on all variant weights (default).
   * *Global, pooled W + H*: one knee on the same pooled curve the upstream elbow uses.
   * *Per cluster*: a separate knee for each W column (variants) and H row (traits).
   The upstream elbow and a manual threshold are available for comparison.
5. **Allocation** — a variant belongs to every cluster in which W ≥ cutoff (soft clustering);
   traits with H ≥ cutoff define each cluster.

### References
* Udler MS et al. Type 2 diabetes genetic loci informed by multi-trait associations point to disease
  mechanisms and subtypes: a soft clustering analysis. *PLoS Med* 2018;15:e1002654.
* Smith K, Deutsch AJ et al. Multi-ancestry polygenic mechanisms of type 2 diabetes.
  *Nat Med* 2024;30:1065–1074.
* Tan VYF, Févotte C. Automatic relevance determination in NMF with the β-divergence.
  *IEEE TPAMI* 2013;35:1592–1605.
* Christopoulos DT. Introducing Unit Invariant Knee (UIK) as the best estimator of a curve's knee.
  *SSRN* 2016; R package `inflection`.
