#!/bin/bash
# macOS double-click launcher. Requires R (https://cran.r-project.org) on PATH.
cd "$(dirname "$0")"
Rscript install_packages.R && Rscript run_app.R
